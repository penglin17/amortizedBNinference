import pickle

f=open('inf_full_connected_score_n3_std1.0_pen1.pkl','rb')
model=pickle.load(f)

print (model)