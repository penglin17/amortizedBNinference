import torch
import torch.nn as nn

n=3
uniary=torch.rand(n**2)
print (uniary)

binary=torch.rand(n**2,n**2)

binary[0][1]=1
binary[4][5]=1
binary[3][5]=1

print (binary)


def binary_mask(structure, n):
    # binary vector of size n**2 x n**2
    # denote the connectivity in the grid of ising model
    if structure == 'grid':
        mask = torch.zeros(n ** 2, n ** 2)
        for i in range(n ** 2):
            for j in range(i + 1, n ** 2):
                # if torch.rand(1) < 0.9:
                #     mask[i][j] = 1
                if i + 1 == j and (i + 1) % n != 0:
                    mask[i][j] = 1
                if j - i == n and i < n ** 2 - 1:
                    mask[i][j] = 1
        return mask
    elif structure == 'full_connected':
        mask = torch.zeros(n ** 2, n ** 2)
       # for i in range(n ** 2):
       #     for j in range(i + 1, n ** 2):
       #         mask[i][j] = 1

        mask[0][2]=1
        mask[0][1]=1
        mask[1][2] = 1
        mask[1][3] = 1
        mask[1][4] = 1
        mask [3][5]=1
        mask[3][7] = 1
        mask[4][5]=1
        mask[4][6] = 1
        mask[5][6] = 1
        mask[5][7] = 1
        mask[5][8] = 1


        return mask

bmask = binary_mask("full_connected", n)
binary_idx = []
for i in range(n**2):
    for j in range(n**2):
        if bmask[i][j].item() > 0:
           binary_idx.append((i,j))
#mymask=binary_mask("full_connected",n)


myfactors=binary*bmask

print (myfactors)
print (binary_idx)


binary_factors = {}
for k, (i,j) in enumerate(binary_idx):
    binary_factor = binary[i][j] # J_ij
    binary_factor = torch.stack([binary_factor, -binary_factor], 0)
    binary_factor = torch.stack([binary_factor, -binary_factor], 1) # 2 x 2
    #print (binary_factor)

