import numpy as np
import torch


file='diabetes.txt'
f=open(file,'r')# read the edge factors
dataset=[]

sourcelines=f.readlines()
for line in sourcelines:
    temp1=line.strip()
    temp2=temp1.split()
   # if len(temp2):
    dataset.append(temp2)

f.close()

#print (dataset)
datasetnew=[]
for j in range(0,len(dataset)):
    if int(dataset[j][0])==1:
        datasetnew.append(dataset[j])
    elif int(dataset[j][0])==2:
        datapoint=[dataset[j][1],dataset[j][2]]
       # datapoint=sorted(datapoint, key=lambda info: (int(info)))
        datasetnew.append(['2',datapoint[0],datapoint[1]])
    elif int(dataset[j][0])==3:
        datapoint=[dataset[j][1],dataset[j][2],dataset[j][3]]
      #  datapoint=sorted(datapoint, key=lambda info: (int(info)))
        datasetnew.append(['2',datapoint[0],datapoint[2]])
        datasetnew.append(['2',datapoint[1],datapoint[2]])

for t in range(0,len(datasetnew)):
   # if int(dataset[t][0])==3:
     print (datasetnew[t])