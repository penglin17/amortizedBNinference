import pickle

import numpy as np
import torch

str='full_connected3std0.1train2000test1000.pkl'
#str='full_connected4std0.1train2000test1000.pkl'
#str='grid5std0.1train4000test1000.pkl'
f=open(str,'rb')

model=pickle.load(f)
torch.set_printoptions(threshold=np.inf)

print (model.keys())
print (model['train'][0][0])
print (model['train'][1][0])

#model['train'][0][0][0]=-1.
#pickle.dump(model,open(str,'wb'))
#print (model['train'][0][0])
print (model)
#print (np.exp(myvec))
#print (np.sum(np.exp(myvec)))
#print (len(myvec))