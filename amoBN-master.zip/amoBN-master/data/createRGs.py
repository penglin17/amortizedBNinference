import numpy as np
import torch


file='pigs.txt'
f=open(file,'r')# read the edge factors
dataset=[]
added=[]
map={}
count=0

sourcelines=f.readlines()
for line in sourcelines:
    temp1=line.strip()
    temp2=temp1.split()
   # if len(temp2):
    dataset.append(temp2)

f.close()

for j in range(0,len(dataset)):
    if int(dataset[j][0])==1:
        if dataset[j][1] not in added:
            map[dataset[j][1]]='x'+str(count)
            count=count+1
            added.append(dataset[j][1])
    elif int(dataset[j][0])==2:
        if dataset[j][2] not in added:
            map[dataset[j][2]] = 'x' + str(count)
            count = count + 1
            added.append(dataset[j][2])

print (len(map))
print ()
for t in range(0,len(dataset)):
    if int(dataset[t][0])==1:
        dataset[t][1]=map[dataset[t][1]]
    if int(dataset[t][0])==2:
        dataset[t][1]=map[dataset[t][1]]
        dataset[t][2]=map[dataset[t][2]]
    if int(dataset[t][0])==3:
        dataset[t][1]=map[dataset[t][1]]
        dataset[t][2]=map[dataset[t][2]]
        dataset[t][3]=map[dataset[t][3]]

for k in range(0,len(dataset)):
    print(dataset[k])