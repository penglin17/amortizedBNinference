import sys
import os
import argparse
from parse import parse
import json
import random
import shutil
import copy
import pickle
import torch
from torch import cuda
import numpy as np
import time
import logging

import pandas as pd
from torch.nn.init import xavier_uniform_
from functools import partial

from rens.models import BN_model as ising_models
from rens.utils.utils import corr, l2, l1, get_scores, binary2unary_marginals, get_freer_gpu
from rens.models.inference_BN_model import bp_infer, p2cbp_infer, mean_field_infer, bethe_net_infer, kikuchi_net_infer

# Model options
parser = argparse.ArgumentParser()
parser.add_argument('--structure', default='grid', type=str, help="Graph structure: grid | BN")
parser.add_argument('--n', default=5, type=int, help="ising grid size")
parser.add_argument('--exp_iters', default=5, type=int, help="how many times to run the experiment")
parser.add_argument('--msg_iters', default=200, type=int, help="max number of inference steps")
parser.add_argument('--enc_iters', default=200, type=int, help="max number of encoder grad steps")
parser.add_argument('--eps', default=1e-5, type=float, help="threshold for stopping inference/sgd")
parser.add_argument('--num_layers', default=1, type=int)
parser.add_argument('--state_dim', default=200, type=int)
parser.add_argument('--lr', default=0.001, type=float)
parser.add_argument('--agreement_pen', default=10, type=float, help='')
parser.add_argument('--device', default='cpu', type=str, help='which gpu to use')
parser.add_argument('--seed', default=3435, type=int, help='random seed')
parser.add_argument('--optmz_alpha', action='store_true', help='whether to optimize alphas in alpha bp')
parser.add_argument('--damp', default=0.5, type=float, help='')
parser.add_argument('--unary_std', default=1.0, type=float, help='')

parser.add_argument('--task', default="infer_result_n5_std1.0.txt", type=str, help='the task to carry on.')
parser.add_argument('--sleep', default=1, type=int, help='sleep a time a beginning.')


    

def run_marginal_exp(args, seed=3435, verbose=True):
    '''compare the marginals produced by mean field, loopy bp, and inference network'''
    np.random.seed(seed)
    torch.manual_seed(seed)
    
    ising = ising_models.BNM(args.n, args.unary_std, args.device, args.structure)
    ising.push2device(args.device)

    #log_Z = ising.log_partition_ve()
    #unary_marginals, binary_marginals = ising.marginals()
    #print (unary_marginals)
    #p_get_scores = partial(get_scores, true_ub=(unary_marginals, binary_marginals))
    ising.generate_region_graph()

    all_scores ={}


    # loopy bp
    if 'bp' in args.method:
        time_start = time.time()
        mrgnl_bp = bp_infer(ising, args, 'lbp')
        scores_bp = p_get_scores(test_ub=(mrgnl_bp[1], mrgnl_bp[2]))
        time_end = time.time()
        all_scores['bp'] = {'l1': scores_bp[0], 'corr': scores_bp[1],\
                            'time': time_end - time_start,\
                            'logz_err': torch.abs(log_Z - mrgnl_bp[0]).to('cpu').data.numpy()}
        print('Finish {} ...'.format('bp'))



    # Generalized belief propagation
    if 'gbp' in args.method:
        time_start = time.time()
        gbp_infer = p2cbp_infer(ising, args)
        mrgnl_gbp = gbp_infer()
        print()
        print("gbp marginal results:")
        for j in range(0, len(mrgnl_gbp[1])):
            print(str(1 - mrgnl_gbp[1][j].item()) + "," + str(mrgnl_gbp[1][j].item()))

        print()
        print("logZ=" + str(mrgnl_gbp[0].item()))
        #scores_gbp = p_get_scores(test_ub=(mrgnl_gbp[1].to(unary_marginals), mrgnl_gbp[2].to(unary_marginals)))
        time_end = time.time()
        all_scores['gbp'] = {
                             'time': time_end - time_start, \
                             }
        print('Finish {} ...'.format('gbp'))

    # Bethe net
    if 'bethe' in args.method:
        time_start = time.time()
        bethe_net = bethe_net_infer(ising, args)
        mrgnl_bethe = bethe_net()
        print("Bethe results:")
        #print(mrgnl_bethe[1])
        # print(mrgnl_kikuchi[2].to(unary_marginals))
        #print(mrgnl_bethe[0])
        for j in range(0, len(mrgnl_bethe[1])):
            print(str(1 - mrgnl_bethe[1][j].item()) + "," + str(mrgnl_bethe[1][j].item()))
        # print(mrgnl_kikuchi[2])
        print()
        print("logZ=" + str(mrgnl_bethe[0].item()))
        #scores_bethe = p_get_scores(test_ub=(mrgnl_bethe[1], mrgnl_bethe[2]))
        time_end = time.time()
        all_scores['bethe'] = {
                               'time': time_end - time_start, \
                                }
        print('Finish {} ...'.format('bethe'))




    # Generalized net
    if 'kikuchi' in args.method:
        time_start = time.time()
        kikuchi_net = kikuchi_net_infer(ising, args)
        mrgnl_kikuchi = kikuchi_net()
        print ()
        print ("kikuchi marginal results:")
        for j in range (0,len(mrgnl_kikuchi[1])):
            print (str(1-mrgnl_kikuchi[1][j].item())+","+str(mrgnl_kikuchi[1][j].item()))
       # print(mrgnl_kikuchi[2])
        print ()
        print("logZ="+str(mrgnl_kikuchi[0].item()))
        #print(log_Z)
        #scores_kikuchi = p_get_scores(test_ub=(mrgnl_kikuchi[1].to(unary_marginals), mrgnl_kikuchi[2].to(unary_marginals)))
        time_end = time.time()
        all_scores['kikuchi'] = {
                                 'time': time_end - time_start, \
                                 }
        print('Finish {} ...'.format('kikuchi'))
        

    if verbose:
        print("This round results:\n {}".format(pd.DataFrame(all_scores)))
    return all_scores

    
if __name__ == '__main__':
    args = parser.parse_args()
    # run multiple number of experiments, and collect the stats of performance.
    # args.method = ['mf', 'bp', 'gbp', 'bethe', 'kikuchi']
    # parsing the task first
    _, num_node, unary_std, penalty = parse("{}_n{}_std{}_pen{}.txt", args.task)
    args.n = int(num_node)
    args.unary_std = float(unary_std)
    args.agreement_pen = float(penalty)
    

   # args.method = ['mf','bp', 'dbp','gbp','bethe', 'kikuchi']
    args.method = ['kikuchi']
   # args.method = ['gbp','bethe', 'kikuchi']
    time.sleep(np.random.randint(args.sleep))
    if args.device != 'cpu':
        args.device = torch.device('cuda:{}'.format(int(get_freer_gpu()) ))
    
    results = {key: {'time':[]} for key in args.method}
    # check if nan in results
    def valid_exp(d):
        valid= True
        for key, value in d.items():
            for crt, score in value.items():
                if np.isnan(score):
                    valid=False
        return valid
        
    for k in range(args.exp_iters):
        d = run_marginal_exp(args, k+10)
        if not valid_exp(d):
                continue

        for key, value in d.items():
            for crt, score in value.items():
                results[key][crt].append(score)

    for key, value in results.items():
        for crt, score in value.items():
            results[key][crt] = {'mu': np.array(score).mean().round(decimals=6), \
                                 'std': np.std(np.array(score)).round(decimals=6)}
    
    print('Average results: \n')
    with pd.option_context('display.max_rows', None, 'display.max_columns', 1000):
        print(pd.DataFrame.from_dict(results, orient='index'))

    pkl_dir = args.task.replace('txt', 'pkl')
    with open(pkl_dir, 'wb') as handle:
        pickle.dump(results, handle)

    sys.exit(0)

  
