
#  setup
create a virtual environment:
```bash
$ virtualenv -p python3.9 pyenv
```
activate your environment:

``` bash
$ source pyenv/bin/activate
```
install the requirement file:

``` bash
$ pip install -r requirements.txt

```

``` bash
$ python setup.py develop

```
#  example


To compute marginals for a BN:
```
make -f completeMakefile BN_infer
```





